## 0.1.7
* fix standard not being a dev dependency

## 0.1.6

* add distance squared (thanks @TheDudeFromCI)
* fix typings (thanks @iczero)

## 0.1.5

* normalize() : like unit() but do not create a new vector (in-place)
* dot(other) : return the dot product of the vector with other
* cross(other) : return the cross product of the vector with other


## 0.1.4

* add typescript declarations
* add more methods
