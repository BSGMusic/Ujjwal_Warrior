const Entity = require('./')

const entity = new Entity(0)

console.log(entity)
