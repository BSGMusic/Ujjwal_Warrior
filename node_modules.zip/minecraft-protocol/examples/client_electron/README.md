# client_electron

* npm install
* npm start
