# History

## 1.3.0

* use protodef compiler, making prismarine-nbt much much faster (10x), thanks @Karang

## 1.2.1

* fix long array : the countType is i32 not i64

## 1.2.0

* add long array

## 1.1.1

* remove fs.read for webpack

## 1.1.0

* fix nbt.simplify

## 1.0.0

* add little endian nbt support (for mcpe)

## 0.2.2

* get back to full es5

## 0.2.1

* update protodef

## 0.2.0

* add simplify

## 0.1.0

* completely reimplement using ProtoDef, the API is mostly compatible with the old version

## 0.0.1

* import from nbt.js + changes to make writing possible
