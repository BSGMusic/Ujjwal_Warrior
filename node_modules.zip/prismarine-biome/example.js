const Biome = require('./')('1.8')

const ocean = new Biome(0)

console.log(ocean)
