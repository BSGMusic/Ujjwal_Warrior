## History

### 1.0.8

* Fix NBT enchantment issue on 1.13 clients (thanks @embeddedt)

### 1.0.7

* Use prismarine-nbt to cleanly handle nbt + check for name enchantments post-flattening

### 1.0.6

* fix Depth Strider Enchantment not working

### 1.0.5

* Handle missing nbt data for boots

### 1.0.4

* Fix null block error

### 1.0.3

* Improve 1.13+ physics (thanks @IdanHo)

### 1.0.2

* Fix undefined block when chunk not loaded

### 1.0.1

* Account for bounding boxes below player (thanks @zubearc)

### 1.0.0

* initial implementation