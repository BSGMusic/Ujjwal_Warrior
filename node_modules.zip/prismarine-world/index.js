module.exports = require('./src/world.js')
