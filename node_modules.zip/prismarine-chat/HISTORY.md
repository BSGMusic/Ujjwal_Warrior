## History

### 1.0.3

* by default hide warnings

### 1.0.2

* ignore mojangson parsing error

### 1.0.1

* make lang option in toAnsi optional

### 1.0.0

* initial implementation
* extracted from mineflayer