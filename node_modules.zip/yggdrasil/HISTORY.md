## History

## 1.4.0
* Add ability to request user from token refresh (thanks @ph0t0shop)

## 1.3.0
- improve code (@IdanHo)
- add proxy support (@IdanHo)

## 1.2.0
- Fix phin error handler @rom1504
- Handle CloudFlare errors @wvffle
